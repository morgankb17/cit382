import React from "react";
import "./styles.css";

export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = { items: [], input: "" };
  }
  handleAddEvent(e) {
    console.log("handleAddEvent()");
    // Only store valid input data
    if (this.state.input.trim().length > 0) {
      // Destructuring: https://wesbos.com/destructuring-objects/
      const { items, input } = this.state;
      items.push(input.trim());
      // Shorthand object syntax: https://devhints.io/es6
      this.setState({ items: items.sort(), input: "" });
    }
  }
  handleClearEvent(e) {
    this.setState({ input: "" });
    console.log("handleClearEvent()");
  }
  handleInputChange(e) {
    console.log("handleInputChange()");
    console.log("Input: ", e.target.value);
    this.setState({ input: e.target.value });
  }
  render() {
    console.log("render()");
    console.log("State items array length: ", this.state.items.length);
    return (
      <div className="App">
        <h1>CIT 382 20W - Lab 04</h1>
        Input: &nbsp;
        <input
          type="text"
          onChange={this.handleInputChange.bind(this)}
          value={this.state.input}
        />
        &nbsp;<button onClick={this.handleAddEvent.bind(this)}>Add</button>
        &nbsp;<button onClick={this.handleClearEvent.bind(this)}>Clear</button>
        <p>Items</p>
        {this.state.items.map((item, index) => (
          <div key={index}>{item}</div>
        ))}
      </div>
    );
  }
}
