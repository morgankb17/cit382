import React from "react";
import "./styles.css";

const user = {
  firstName: "Harper",
  lastName: "Perez"
};

function Greeting(props) {
  // Setup user
  let user = "";
  if (props.user) {
    if (props.user.firstName && props.user.firstName.trim().length > 0) {
      user = props.user.firstName.trim();
    }
    if (props.user.lastName && props.user.lastName.trim().length > 0) {
      if (user.length > 0) user += " ";
      user += props.user.lastName.trim();
    }
    if (user.length === 0) {
      user = "Stranger";
    }
  }
  return <div className="divClass">Hello, {user}!</div>;
}

class GreetingClass extends React.Component {
  constructor(props) {
    super(props);
    // Only time explicitly set state, use setState() for all other changes
    this.state = {
      language: this.props.language ? this.props.language : "English"
    };
  }
  getHello() {
    switch (this.state.language) {
      case "French":
        return "Bonjour";
      case "Spanish":
        return "Hola";
      default:
        return "Hello";
    }
  }
  render() {
    // Setup user
    let user = "";
    if (this.props.user) {
      if (
        this.props.user.firstName &&
        this.props.user.firstName.trim().length > 0
      ) {
        user = this.props.user.firstName.trim();
      }
      if (
        this.props.user.lastName &&
        this.props.user.lastName.trim().length > 0
      ) {
        if (user.length > 0) user += " ";
        user += this.props.user.lastName.trim();
      }
      if (user.length === 0) {
        user = "Stranger";
      }
    }
    return (
      <div className="divClass">
        {" "}
        {this.getHello()}, {user}!
      </div>
    );
  }
}

export default function App() {
  return (
    <div className="App">
      <h1>CIT 382 - 20W - Lab 3</h1>
      <Greeting user={user} />
      <GreetingClass user={user} language="French" />
    </div>
  );
}
