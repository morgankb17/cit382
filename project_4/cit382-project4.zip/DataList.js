import React, { useState } from "react";

export function DataList() {
  return (
    <div className="grid-item3">
      <h2>List</h2>
      <li>The</li>
      <li>Actual</li>
      <li>Data</li>
      <li>Will</li>
      <li>Go</li>
      <li>Here</li>
      <button>Clear</button>
    </div>
  );
}
