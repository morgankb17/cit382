import React from "react";
import "./styles.css";

function TroubleMaker({ trouble = 0, incrementTrouble = (f) => f }) {
  return (
    <div>
      <button onClick={incrementTrouble}>Make trouble</button>
      <p>{trouble}</p>
    </div>
  );
}

function SawTrouble({ trouble = 0 }) {
  return <div>Saw trouble: {trouble}</div>;
}

export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = { trouble: 0 };
  }
  incrementTrouble() {
    var trouble = this.state.trouble;
    trouble += 1;
    this.setState({ trouble });
  }
  render() {
    return (
      <div className="App">
        <h1>Lifting State</h1>
        <h2>
          Trouble maker component
          <TroubleMaker
            incrementTrouble={this.incrementTrouble.bind(this)}
            trouble={this.state.trouble}
          />
          Saw trouble component
          <SawTrouble trouble={this.state.trouble} />
        </h2>
      </div>
    );
  }
}
