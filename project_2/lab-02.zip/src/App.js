import React from "react";
import "./styles.css";

function formatName(user) {
  return user.firstName + " " + user.lastName;
}

const user = {
  firstName: "Harper",
  lastName: "Perez"
};

const element = <div>Hello, {formatName(user)}!</div>;

function getGreeting(user) {
  if (user) {
    return <h1>Hello, {formatName(user)}!</h1>;
  }
  return <h1>Hello, Stranger.</h1>;
}

const months = ["January", "February", "March"];

export default function App() {
  const display = (
    <div className="App">
      <h1 className="stripe">CIT 382 - 20W - Lab 2</h1>
      {/*<div className="divClass">{element}</div>*/}
      <div className="divClass">Hello, {formatName(user)}!</div>
      <br />
      <img src="MatrixNiobe.jpg" alt="" />
      <div className="stripe">
        {months.map((month, index) => (
          <div>
            {index + 1}. {month}
          </div>
        ))}
      </div>
    </div>
  );
  return display;
}

getGreeting(user);
